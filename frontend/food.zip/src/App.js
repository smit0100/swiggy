import './App.css';

function App() {
  
  return (
    <h1 className="header bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-rose-100 to-teal-100">
      
      
    </h1>
  );
}

export default App;
